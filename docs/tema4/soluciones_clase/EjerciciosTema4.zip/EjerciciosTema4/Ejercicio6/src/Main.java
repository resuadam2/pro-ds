public class Main {
    public static void main(String[] args) {
        Nif dniPrueba = new Nif();
        dniPrueba.leer();
        System.out.println(dniPrueba);
    }
}
