import java.util.HashMap;

public class Estudiante {
    private String nombre;
    private HashMap<String, Integer> notas;

    public Estudiante(String nombre) {
        this.nombre = nombre;
        this.notas = new HashMap<>();
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public HashMap<String, Integer> getNotas() {
        return notas;
    }

    public void setNotas(HashMap<String, Integer> notas) {
        this.notas = notas;
    }

    @Override
    public String toString() {
        return "Estudiante{" +
                "nombre='" + nombre + '\'' +
                ", notas=" + notas +
                '}';
    }
}
