import java.io.*;
import java.util.HashMap;
import java.util.InputMismatchException;
import java.util.Scanner;

public class GestionNotas {
    private static final String FICHERO_ESTUDIANTES = "estudiantes.txt";
    private static final Scanner SC = new Scanner(System.in);
    private static HashMap<String, Estudiante> estudiantes = new HashMap<>();

    public static void main(String[] args) {
        crearFichero(); // Crea el fichero si no existe
        leerFichero(); // Lee el fichero y rellena el arraylist

        String option;
        do {
            mostrarMenu();
            option = SC.nextLine();

            switch (option) {
                case "1" -> registrarEstudiante();
                case "2" -> nuevaNota();
                case "3" -> mostrarNotasEstudiante();
                case "4" -> mostrarEstudiantes();
                case "5" -> System.out.println("Fin del programa.");
                default -> System.out.println("Seleccione una opción válida.");
            }
        }while(!option.equals("5"));
    }

    private static void registrarEstudiante() {
        System.out.println("Introduzca el nombre del estudiante: ");
        String nombre = SC.nextLine();
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(FICHERO_ESTUDIANTES, true))) {
            bw.write(nombre + "\n");
            String file = "notas_" + nombre + ".txt";
            File ficheroNotas = new File(file);
            if (ficheroNotas.createNewFile()) {
                System.out.println("Fichero de notas de " + nombre + " creado.");
            } else {
                System.out.println("El fichero de notas de " + nombre + " no fue creado porque ya existía.");
            }
            estudiantes.put(nombre, new Estudiante(nombre));
        } catch (IOException e) {
            System.out.println("ERROR AÑADIENDO ESTUDIANTE " + nombre);
        }
    }

    private static void nuevaNota() {
        mostrarEstudiantes();
        if (!estudiantes.isEmpty()) {
            System.out.println("Seleccione un estudiante: ");
            String nombre = SC.nextLine();
            if (estudiantes.containsKey(nombre)) {
                System.out.println("Introduzca la clave de la nueva nota: ");
                String clave = SC.nextLine();
                boolean notaOk = true;
                int valor = 0;
                do {
                    try {
                        System.out.println("Introduzca el valor de la nueva nota (solo enteros)");
                        valor = Integer.parseInt(SC.nextLine());
                        notaOk = true;
                    } catch (InputMismatchException ime) {
                        notaOk = false;
                        System.out.println("Debe ser un entero.");
                    }
                } while (!notaOk);
                estudiantes.get(nombre).getNotas().put(clave, valor);
                String file = "notas_" + nombre + ".txt";
                try (BufferedWriter bw = new BufferedWriter(new FileWriter(file, true))) {
                    bw.write(clave + "=" + valor + "\n");
                    System.out.println("Nota registrada en el archivo.");
                } catch (IOException e) {
                    System.out.println("ERROR ESCRIBIENDO EN : " + file);
                }
            } else {
                System.out.println("El estudiante introducido no está registrado.");
            }
        }
    }

    private static void mostrarNotasEstudiante() {
        mostrarEstudiantes();
        if (!estudiantes.isEmpty()) {
            System.out.println("Seleccione un estudiante: ");
            String nombre = SC.nextLine();
            if (estudiantes.containsKey(nombre)) {
                Estudiante aux = estudiantes.get(nombre);
                System.out.println("Notas de " + aux.getNombre());
                for(String notas : aux.getNotas().keySet()) {
                    System.out.println(notas + " : " + aux.getNotas().get(notas));
                }
            } else {
                System.out.println("El estudiante introducido no está registrado.");
            }
        }
    }

    /*
    Versión sin el HashMap:
    private static void mostrarTodosLosEstudiantes() {
        System.out.println("\nListado de estudiantes:");

        try (BufferedReader br = new BufferedReader(new FileReader(FICHERO_ESTUDIANTES))) {
            String linea;
            boolean ficheroVacio = true;
            while ((linea = br.readLine()) != null) {
                ficheroVacio = false;
                System.out.println("- " + linea);
            }

            if (ficheroVacio) {
                System.out.println("No hay estudiantes registrados.");
            }

        } catch (IOException e) {
            System.out.println("Error al leer el fichero de estudiantes.");
        }
    }
     */

    private static void mostrarEstudiantes() {
        System.out.println("\nListado de estudiantes:");
        if (estudiantes.isEmpty()) System.out.println("No hay estudiantes registrados.");
        else {
            for (String estudiante : estudiantes.keySet()) {
                System.out.println(estudiante);
            }
        }
    }

    private static void mostrarMenu() {
        System.out.println("------- Menú Gestión de Notas --------");
        System.out.println("1. Registrar nuevo estudiante.");
        System.out.println("2. Añadir nota a estudiante.");
        System.out.println("3. Mostrar notas de un estudiante.");
        System.out.println("4. Mostrar todos los estudiantes.");
        System.out.println("5. Salir. ");
        System.out.println("Seleccione una opción válida (1-5).");
    }

    private static void leerFichero() {
        try (BufferedReader br = new BufferedReader(new FileReader(FICHERO_ESTUDIANTES))) {
            String linea;
            boolean vacio = true;
            while ((linea = br.readLine()) != null) {
                vacio = false;
                estudiantes.put(linea, new Estudiante(linea));
                leerNotasEstudiante(linea);
            }
        } catch (IOException e) {
            System.out.println("ERROR LEYENDO ARCHIVO DE ESTUDIANTES: " + FICHERO_ESTUDIANTES);
        }
    }

    private static void leerNotasEstudiante(String nombre) {
        String file = "notas_" + nombre + ".txt";
        try (BufferedReader br = new BufferedReader(new FileReader(file))) {
            String linea;
            boolean vacio = true;
            while ((linea = br.readLine()) != null) {
                vacio = false;
                String lineaNota[] = linea.split("="); // tema1=8
                estudiantes.get(nombre).getNotas().put(lineaNota[0], Integer.parseInt(lineaNota[1]));
            }
        } catch (IOException e) {
            System.out.println("ERROR LEYENDO ARCHIVO DE NOTAS: " + file);
        }

    }

    private static void crearFichero() {
        File file = new File(FICHERO_ESTUDIANTES);
        try {
            if (file.createNewFile()) {
                System.out.println("Fichero creado: " + FICHERO_ESTUDIANTES);
            }
        } catch (IOException e) {
            System.out.println("Error al crear el fichero: " + FICHERO_ESTUDIANTES);
        }
    }
}
