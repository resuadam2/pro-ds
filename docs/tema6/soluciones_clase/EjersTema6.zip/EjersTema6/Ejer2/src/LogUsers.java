import java.io.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

public class LogUsers {
    private static final String RUTA_FICHERO = "log_usuarios.txt";
    private static final Scanner SC = new Scanner(System.in);
    private static final DateTimeFormatter FORMATO_FECHA = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

    public static void main(String[] args) {
        File file = new File(RUTA_FICHERO);
        try {
            if (file.createNewFile()) {
                System.out.println("El fichero 'log_usuarios.txt' ha sido creado.");
            } else {
                System.out.println("El fichero 'log_usuarios.txt' ya existe.");
            }
        } catch (IOException e) {
            System.out.println("Error al crear o acceder al fichero 'log_usuarios.txt'.");
            return;
        }
        String option = "";
        do {
            mostrarMenu();
            option = SC.nextLine();
            switch (option) {
                case "1" -> registrarEvento("LOGIN");
                case "2" -> registrarEvento("LOGOUT");
                case "3" -> mostrarLogs();
                case "4" -> System.out.println("Fin del programa.");
                default -> System.out.println("Seleccione una opción válida.");
            }
        } while (!option.equalsIgnoreCase("4"));
        SC.close();
    }

    private static void registrarEvento(String tipoEvento) {
        System.out.println("Introduzca el nombre del usuario:");
        String nombre = SC.nextLine();
        String fechaHora = LocalDateTime.now().format(FORMATO_FECHA);
        String log = "[" + fechaHora + "] " + tipoEvento + " -> " + nombre + "\n";
        try(BufferedWriter bw = new BufferedWriter(new FileWriter(RUTA_FICHERO, true))) {
            bw.write(log);
            System.out.println("Log registrado.");
        } catch (IOException ioe) {
            System.out.println("ERROR: ERROR en la escritura.");
        }
    }

    private static void mostrarLogs() {
        System.out.println("CONTENIDO DEL FICHERO:\n");
        boolean vacio = true;
        try(FileReader fr = new FileReader(RUTA_FICHERO)) {
            int caracter;
            while ((caracter = fr.read()) != -1) {
                vacio = false;
                System.out.print((char) caracter);
            }
            if (vacio) System.out.println("El archivo no tiene contenido por el momento.");
            System.out.println();
        } catch (FileNotFoundException e) {
            System.out.println("ERROR: FICHERO NO ENCONTRADO.");
        } catch (IOException e) {
            System.out.println("ERROR: ERROR DE E/S.");
        }
    }

    private static void mostrarMenu() {
        System.out.println("------ Menú de Gestión de Usuarios -----\n");
        System.out.println("1. Login de usuario.");
        System.out.println("2. Logout de usuario.");
        System.out.println("3. Mostrar log completo.");
        System.out.println("4. Salir.\n");
        System.out.println("Seleccione una opción (1-4):");
    }
}
