import java.io.*;
import java.util.List;
import java.util.Scanner;

public class GestionUsuarios {
    private static final String PATH_FILE = "users.txt";
    private static final Scanner SC = new Scanner(System.in);

    public static void main(String[] args) {
        File file = new File(PATH_FILE);
        try {
            if (file.createNewFile()) {
                System.out.println("El fichero 'users.txt' ha sido creado.");
            } else {
                System.out.println("El fichero 'users.txt' ya existe.");
            }
        } catch (IOException e) {
            System.out.println("Error al crear o acceder al fichero 'users.txt'.");
            return;
        }
        String option = "";
        do {
            showMenu();
            option = SC.nextLine();
            switch (option) {
                case "1" -> addUser();
                case "2" -> showUsers();
                case "3" -> findUserByName();
                case "0" -> System.out.println("Fin del programa.");
                default -> System.out.println("Seleccione una opción válida.");
            }
        } while (!option.equalsIgnoreCase("0"));
        SC.close();
    }

    private static void findUserByName() {
        try (BufferedReader br = new BufferedReader(new FileReader(PATH_FILE))) {
            List<String> lines = br.lines().toList();
            if (lines.isEmpty()) {
                System.out.println("El fichero está vacío.");
                return;
            }
            System.out.println("Introduce el nombre a buscar: ");
            String nameSearched = SC.nextLine();
            boolean found = false;
            for (String line: lines) {
                String[] data = line.split(",");
                String name = data[0];
                if (nameSearched.equalsIgnoreCase(name)) {
                    found = true;
                    System.out.println("Nombre: " + data[0] + " | Edad: " + data[1] + " | Ciudad: " + data[2]);
                    // break; // Meto esto si solo quiero sacar la primera coincidencia
                    // Si no incluyo el break, se va a leer el archivo hasta el final, sacando todas las coincidencias
                }
            }
            if (!found) System.out.println("Usuario no encontrado.");
        } catch (FileNotFoundException e) {
            System.out.println("ERROR: Fichero no encontrado.");
        } catch (IOException e) {
            System.out.println("ERROR: Error en la E/S de datos.");
        }
    }

    private static void showUsers() {
        try (BufferedReader br = new BufferedReader(new FileReader(PATH_FILE))) {
            String line;
            boolean empty = true;
            System.out.println("Lista de usuarios: ");
            while ((line = br.readLine()) != null) {
                empty = false;
                String[] data = line.split(",");
                System.out.println("Nombre: " + data[0] + " | Edad: " + data[1] + " | Ciudad: " + data[2]);
            }
            if (empty) System.out.println("El fichero está vacío.");
        } catch (FileNotFoundException e) {
            System.out.println("ERROR: Fichero no encontrado.");
        } catch (IOException e) {
            System.out.println("ERROR: Error en la E/S de datos.");
        }
    }

    private static void addUser() {
        System.out.println("Introduzca el nombre:");
        String name = SC.nextLine();
        int age = 0;
        try {
            System.out.println("Introduzca su edad");
            age = Integer.parseInt(SC.nextLine());
            if (age < 0) throw new NumberFormatException();
        } catch (NumberFormatException numberFormatException) {
            System.out.println("ERROR: La edad debe ser un número entero positivo.");
            return;
        }
        System.out.println("Introduzca la ciudad:");
        String city = SC.nextLine();
        // FileWriter fw = null;
        try (FileWriter fw = new FileWriter(PATH_FILE, true)) {
            // FileWriter ...
            fw.write(name + "," + age + "," + city + "\n");
            System.out.println("Usuario añadido correctamente.");
        } catch (IOException e) {
            System.out.println("Error al escribir datos en el fichero.");
        }
        /*
         finally {
          fw.flush() o fw.close()
          }
         */
    }

    private static void showMenu() {
        System.out.println("------ Menú de Gestión de Usuarios -----\n");
        System.out.println("1. Nuevo usuario.");
        System.out.println("2. Mostrar usuarios.");
        System.out.println("3. Buscar usuario por nombre.");
        System.out.println("0. Salir del programa.\n");
        System.out.println("Seleccione una opción (0-3):");
    }
}
