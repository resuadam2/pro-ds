import java.util.Scanner;

public class Main {
    private static final Scanner sc = new Scanner(System.in);
    private static final Biblioteca biblioteca = new Biblioteca();

    public static void main(String[] args) {
        String option;
        do {
            mostrarMenu();
            option = sc.nextLine();
            switch (option) {
                case "1" -> nuevoLibro();
                case "2" -> biblioteca.listarLibros();
                case "3" -> buscarOBorrarLibro(false);
                case "4" -> buscarOBorrarLibro(true);
                case "0" -> System.out.println("Fin del programa.");
                default -> System.out.println("Seleccione una opción válida (0-4).");
            }
        } while(!option.equalsIgnoreCase("0"));
        sc.close();
    }

    private static void nuevoLibro() {
        System.out.println("Código: ");
        String codigo = sc.nextLine();
        System.out.println("Títutlo: ");
        String titulo = sc.nextLine();
        System.out.println("Autor: ");
        String autor = sc.nextLine();
        System.out.println("Año de publicación: ");
        int anio = Integer.parseInt(sc.nextLine());
        Libro libro = new Libro(codigo, titulo, autor, anio);
        biblioteca.addLibro(libro);
    }

    private static void buscarOBorrarLibro(boolean borrando) {
        System.out.println("Introduzca el código del libro: ");
        String codigo = sc.nextLine();
        if (borrando) biblioteca.borrarLibro(codigo);
        else biblioteca.buscarLibro(codigo, false);
    }

    private static void mostrarMenu() {
        System.out.println("\n----Gestión de la biblioteca----");
        System.out.println("1. Añadir nuevo libro.");
        System.out.println("2. Listar libros.");
        System.out.println("3. Buscar un libro por código.");
        System.out.println("4. Eliminar libro.");
        System.out.println("0. Salir del programa.");
    }
}
