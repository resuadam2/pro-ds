import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class Biblioteca {
    private List<Libro> libros;
    private final String fichero = "biblioteca.dat";

    public Biblioteca() {
        libros = cargarLibros();
    }

    private List<Libro> cargarLibros() {
        List<Libro> aux = new ArrayList<>();
        File archivo = new File(fichero);

        if (archivo.exists()) {
            try(ObjectInputStream ois = new ObjectInputStream(new FileInputStream(archivo))) {
                aux = (List<Libro>) ois.readObject();
            } catch (IOException | ClassNotFoundException e) {
                System.out.println("ERROR: Error al cargar los datos.");
            }
        }
        return aux;
    }

    private void escribirArchivo() {
        try(ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(fichero))) {
            oos.writeObject(libros);
        } catch (IOException e) {
            System.out.println("ERROR: Error al escribir los datos.");
        }
    }

    public void addLibro(Libro libro) {
        libros.add(libro);
        escribirArchivo();
        System.out.println("Libro añadido.");
    }

    public void borrarLibro(String codigo) {
        Libro libro = buscarLibro(codigo, true);
        if (libro != null) {
            libros.remove(libro);
            escribirArchivo();
            System.out.println("Libro eliminado.");
        } else {
            System.out.println("No se ha encontrado el libro a eliminar.");
        }
    }

    public void listarLibros() {
        if (libros.isEmpty()) {
            System.out.println("Todavía no hay libros añadidos.");
        } else {
            for (Libro libro: libros) System.out.println(libro);
        }
    }

    public Libro buscarLibro(String codigo, boolean borrando) {
        for (Libro libro: libros) {
            if (libro.getCodigo().equalsIgnoreCase(codigo)){
                if (!borrando) {
                    System.out.println("Libro encontrado: ");
                    System.out.println(libro);
                }
                return libro;
            }
        }
        if (!borrando) System.out.println("Libro no encontrado.");
        return null;
    }
}
