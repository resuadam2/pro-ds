import java.io.*;
import java.util.Properties;

public class Config {
    private final String fichero = "config.properties";
    private Properties propiedades;

    private final String IDIOMA_KEY = "idioma";
    private final String TEMA_KEY = "tema";
    private final String FUENTE_KEY = "tamaño_fuente";
    private final String TUTORIAL_KEY = "mostrar_tutorial";

    private final String IDIOMA_POR_DEFECTO = "es";
    private final String TEMA_POR_DEFECTO = "claro";
    private final String FUENTE_POR_DEFECTO = "12";
    private final String TUTORIAL_POR_DEFECTO = "true";



    public Config() {
        propiedades = new Properties();
        cargarPropiedades();
    }

    public Properties getPropiedades() {
        return propiedades;
    }

    private void cargarPropiedades() {
        File file = new File(fichero);

        if (!file.exists()) {
            crearPropiedadesPorDefecto();
        }

        try(FileInputStream fis = new FileInputStream(file)) {
            propiedades.load(fis);;
        } catch (IOException e) {
            System.out.println("ERROR: Error al leer el fichero de propiedades.");
            System.out.println(e.getMessage());
        }
    }

    private void crearPropiedadesPorDefecto() {
        propiedades.setProperty(IDIOMA_KEY, IDIOMA_POR_DEFECTO);
        propiedades.setProperty(TEMA_KEY, TEMA_POR_DEFECTO);
        propiedades.setProperty(FUENTE_KEY, FUENTE_POR_DEFECTO);
        propiedades.setProperty(TUTORIAL_KEY, TUTORIAL_POR_DEFECTO);

        guardarPropiedadades();
    }

    private void guardarPropiedadades() {
        try(FileOutputStream fos = new FileOutputStream(fichero)) {
            propiedades.store(fos, "Configuración de la aplicación");
        } catch (IOException e) {
            System.out.println("ERROR: Error al escribir las propiedades.");
            System.out.println(e.getMessage());
        }
    }

    public void restaurarPorDefecto() {
        crearPropiedadesPorDefecto();
        System.out.println("Las propiedades se han restaurado a su valor por defecto.");
    }

    public void mostrarPropiedades() {
        System.out.println("Configuración actual en el fichero:");
        for(String propertie : propiedades.stringPropertyNames()) {
            System.out.println(propertie + ": " + propiedades.getProperty(propertie));
        }
        /*
            propiedades.forEach((k, v) -> sout( k + ": " + v));
         */
    }

    public void modificarPropiedad(String clave, String valor) {
        if (propiedades.containsKey(clave)) {
            propiedades.setProperty(clave, valor);
            guardarPropiedadades();
            System.out.println("Se ha modificado la propiedad " + clave  + " al nuevo valor: " + valor);
        } else {
            System.out.println("La propiedad indicada no existe. La clave debe indicarse de forma exacta.");
        }
    }
}
