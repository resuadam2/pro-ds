import java.util.Scanner;

public class Main {

    static Config config = new Config();
    static Scanner sc = new Scanner(System.in);
    static String option = "";

    public static void main(String[] args) {
        do {
            mostrarMenu();
            option = sc.nextLine();
            switch (option) {
                case "1" -> mostrarConfig();
                case "2" -> updateConfig();
                case "4" -> restoreConfig();
                case "0" -> System.out.println("Fin del programa");
                default -> System.out.println("Seleccione una opción válida (0-4)");
            }
        } while(!option.equalsIgnoreCase("0"));
    }

    private static void restoreConfig() {
        config.restaurarPorDefecto();
    }

    private static void updateConfig() {
        System.out.println("Posibles claves: ");
        for (String propiertie : config.getPropiedades().stringPropertyNames()) {
            System.out.println(propiertie);
        }
        System.out.println("Ingrese el nombre de la propiedad a modificar: ");
        String key = sc.nextLine();
        System.out.println("Ingrese el nuevo valor para la propiedad " + key + ": ");
        String value = sc.nextLine();
        config.modificarPropiedad(key, value);
    }

    private static void mostrarConfig() {
        config.mostrarPropiedades();
    }

    private static void mostrarMenu() {
        System.out.println("---- Menú de configuración ----");
        System.out.println("1. Mostrar la configuración actual.");
        System.out.println("2. Modificar alguna propiedad de la configuración.");
        System.out.println("4. Restaurar la configuración por defecto.");
        System.out.println("0. Pulse 0 para salir.");
    }
}
