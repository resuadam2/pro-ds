import java.io.IOException;
import java.nio.file.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class GestionTareas {
    private static final String RUTA_FICHERO_TAREAS = "tareas.txt";
    private static final Path PATH_TAREAS = Paths.get(RUTA_FICHERO_TAREAS);
    private static final String RUTA_FICHERO_COPIA = "tareas_copia.txt";
    private static final Scanner sc = new Scanner(System.in);

    public static void main(String[] args) {
        crearFichero();

        String option;
        do {
            mostrarMenu();
            option = sc.nextLine();
            switch (option) {
                case "1" -> nuevaTarea();
                case "2" -> mostrarTareas();
                case "3" -> eliminarTarea();
                case "4" -> crearCopiaSeguridad();
                case "5" -> System.out.println("Fin del programa.");
                default -> System.out.println("Seleccione una opción válida.");
            }
        } while (!option.equalsIgnoreCase("5"));
    }

    private static void crearCopiaSeguridad() {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd_HH-mm");
        String fecha = LocalDateTime.now().format(formatter);

        String archivoCopia = fecha + "_" + RUTA_FICHERO_COPIA;
        Path pathCopia = Paths.get(archivoCopia);

        try {
            Files.copy(PATH_TAREAS, pathCopia, StandardCopyOption.REPLACE_EXISTING);
            System.out.println("Copia de seguridad creada: " + archivoCopia);
        } catch (IOException e) {
            System.out.println("ERROR: Error al crear la copia de seguridad.");
        }
    }

    private static void eliminarTarea() {
        mostrarTareas();

        System.out.println("Introduzca el ID de la tarea a eliminar.");
        String idEliminar = sc.nextLine();

        try {
            List<String> lineas = Files.readAllLines(PATH_TAREAS);
            List<String> nuevasLineas = new ArrayList<>();
            for (String linea: lineas) {
                if (linea.split("\\|")[0].trim().equalsIgnoreCase(idEliminar)) {
                    continue;
                }
                nuevasLineas.add(linea);
            }
            Files.write(PATH_TAREAS, nuevasLineas, StandardOpenOption.TRUNCATE_EXISTING);
        } catch (IOException e) {
            System.out.println("ERROR: Error en la eliminación de la tarea.");
        }
    }

    private static void mostrarTareas() {
        System.out.println("\n Lista de tareas: ");
        try {
            List<String> lineas = Files.readAllLines(PATH_TAREAS);
            if (lineas.isEmpty()) {
                System.out.println("No hay tareas añadidas por el momento.");
            } else {
                for (String linea: lineas) System.out.println(linea);
                // lineas.forEach(System.out::println);
            }
        } catch (IOException e) {
            System.out.println("ERROR: Error en la lectura del fichero.");
        }
    }

    private static void nuevaTarea() {
        System.out.println("Introduzca la descripción de la tarea a añadir:");
        String descripcion = sc.nextLine();
        int nuevoID = siguienteID();
        String linea = nuevoID + " | " + descripcion;
        try {
            Files.write(PATH_TAREAS, List.of(linea), StandardOpenOption.APPEND);
            System.out.println("Tarea añadida.");
        } catch (IOException e) {
            System.out.println("ERROR: Error en la escritura de la nueva tarea.");
        }
    }

    private static int siguienteID() {
        try {
            List<String> lineas = Files.readAllLines(PATH_TAREAS);
            int max = 0;

            for (String linea : lineas ) {
                String[] secciones = linea.split("\\|");
                int id = Integer.parseInt(secciones[0].trim());
                if (id > max) max = id;
            }
            return max + 1;
        } catch (IOException e) {
            System.out.println("ERROR: Error al obtener el ID para añadir una nueva tarea.");
            return 1;
        }
    }

    private static void mostrarMenu() {
        System.out.println("--- MENÚ PRINCIPAL ---");
        System.out.println("1. Añadir una nueva tarea.");
        System.out.println("2. Mostrar todas las tareas.");
        System.out.println("3. Eliminar tarea por ID.");
        System.out.println("4. Crear una copia de seguridad.");
        System.out.println("5. Salir del programa.");
        System.out.println();
        System.out.println("Seleccione una opción del menú (1-5):");
    }

    private static void crearFichero() {
        try {
            if(Files.notExists(PATH_TAREAS)) {
                Files.createFile(PATH_TAREAS);
                System.out.println("Fichero creado.");
            }
        } catch (IOException e) {
            System.out.println("ERROR: Error al crear el fichero.");
        }
    }
}
