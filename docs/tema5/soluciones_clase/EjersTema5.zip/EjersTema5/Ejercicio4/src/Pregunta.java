import java.util.ArrayList;

public class Pregunta<T> {
    private String pregunta;
    private ArrayList<T> opciones;
    private T respuestaCorrecta;

    public Pregunta(String pregunta, ArrayList<T> opciones, T respuesta) {
        this.pregunta = pregunta;
        this.opciones = opciones;
        this.respuestaCorrecta = respuesta;
    }

    public String getPregunta() {
        return pregunta;
    }

    public T getRespuestaCorrecta() {
        return respuestaCorrecta;
    }

    public boolean responder(T respuesta) {
        return respuestaCorrecta == respuesta;
    }
}
