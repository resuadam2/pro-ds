public class PreguntaNumerica {
    private String pregunta;
    private int respuesta;

    public PreguntaNumerica(String pregunta, int respuesta) {
        this.pregunta = pregunta;
        this.respuesta = respuesta;
    }

    public String getPregunta() {
        return pregunta;
    }

    public int getRespuesta() {
        return respuesta;
    }
}
