import java.util.ArrayList;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        PreguntaCorta preguntaCorta = new PreguntaCorta("¿Capital de Francia?", "París");
        PreguntaNumerica preguntaNumerica = new PreguntaNumerica("¿Cuánto es 2 + 3?", 5);
        PreguntaBool preguntaBool = new PreguntaBool("¿Ha llovido hoy?", true);
        Pregunta<String> stringPregunta = new Pregunta<>(
                "¿Capital de Francia?",
                new ArrayList<String>(List.of(new String[]{"París", "Roma", "Madrid", "Vigo"})),
                "París");
//        Pregunta<Integer> integerPregunta = new Pregunta<>("¿Cuánto es 2 + 3?", 5);
//        Pregunta<Boolean> booleanPregunta = new Pregunta<>("¿Ha llovido hoy?", true);
//        Pregunta<Double> doublePregunta = new Pregunta<>("¿Cuánto es 2 + 2.5", 4.5);

        System.out.println("Preguntas que no usan los genéricos:");
        System.out.println(preguntaCorta.getPregunta() + " Respuesta: " + preguntaCorta.getRespuesta());
        System.out.println(preguntaNumerica.getPregunta() + " Respuesta: " + preguntaNumerica.getRespuesta());
        System.out.println(preguntaBool.getPregunta() + " Respuesta: " + preguntaBool.getRespuesta());

        System.out.println("Preguntas que usan los genéricos:");
        System.out.println(stringPregunta.getPregunta() + " Respuesta: " + stringPregunta.getRespuestaCorrecta());
//        System.out.println(integerPregunta.getPregunta() + " Respuesta: " + integerPregunta.getRespuestaCorrecta());
//        System.out.println(booleanPregunta.getPregunta() + " Respuesta: " + booleanPregunta.getRespuestaCorrecta());
//        System.out.println(doublePregunta.getPregunta() + " Respuesta: " + doublePregunta.getRespuestaCorrecta());
        System.out.println("Has respondido: Roma y es " + stringPregunta.responder("Roma"));
        System.out.println("Has respondido: París y es "+ stringPregunta.responder("París"));

    }
}
