public class Bicicleta extends Vehiculo {
    public enum TipoBicicleta {
        MONTANA, CARRETERA, CIUDAD
    }

    private TipoBicicleta tipo;

    public Bicicleta(String marca, String modelo, TipoBicicleta tipo) {
        super(marca, modelo);
        this.tipo = tipo;
    }

    public TipoBicicleta getTipo() {
        return tipo;
    }

    public void setTipo(TipoBicicleta tipo) {
        this.tipo = tipo;
    }

    @Override
    public String toString() {
        return "Bicicleta{" +
                "marca=" + getMarca() +
                ", modelo=" + getModelo() +
                ", tipo=" + tipo +
                '}';
    }
}
