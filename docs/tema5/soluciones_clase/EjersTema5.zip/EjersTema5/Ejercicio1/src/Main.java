public class Main {
    public static void main(String[] args) {
        Coche coche = new Coche("Peugeot", "308", 5, new Motor(1.6, 80));
        Coche coche1 = new Coche("Audi", "A3", 3, new Motor(1.8, 120));
        Camion camion = new Camion("Mercedes", "camión", new Motor(2.5, 200), 5500);
        Bicicleta bici = new Bicicleta("Decathlon", "rápido", Bicicleta.TipoBicicleta.CARRETERA);
        Bicicleta bicicleta = new Bicicleta("Otra marca", "otro modelo", Bicicleta.TipoBicicleta.MONTANA);
        Taller.addVehiculos(coche1);
        Taller.addVehiculos(coche);
        Taller.addVehiculos(bicicleta);
        Taller.addVehiculos(camion);
        Taller.addVehiculos(bici);
        System.out.println("Mostrando vehículos antes de las reparaciones: ");
        Taller.showVehiculos();
        System.out.println();
        System.out.println("Reparamos los vehículos:");
        Taller.repararVehiculos();
        System.out.println();
        System.out.println("Mostrando vehículos después de las reparaciones:");
        Taller.showVehiculos();
    }
}
