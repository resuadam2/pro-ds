public abstract class VehiculoMotorizado extends Vehiculo {
    private Motor motor;

    public VehiculoMotorizado(String marca, String modelo, Motor motor) {
        super(marca, modelo);
        this.motor = motor;
    }

    public Motor getMotor() {
        return motor;
    }

    public void setMotor(Motor motor) {
        this.motor = motor;
    }

    @Override
    public String toString() {
        return "VehiculoMotorizado{" +
                "motor=" + motor +
                '}';
    }
}
