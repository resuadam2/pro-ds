import java.util.ArrayList;

public class Taller {
    private static ArrayList<Vehiculo> vehiculos = new ArrayList<>();


    public static ArrayList<Vehiculo> getVehiculos() {
        return vehiculos;
    }

    public static void setVehiculos(ArrayList<Vehiculo> vehiculos) {
        Taller.vehiculos = vehiculos;
    }

    public static void addVehiculos(Vehiculo vehiculo) {
        vehiculos.add(vehiculo);
    }

    public static void repararVehiculos() {
        ArrayList<Vehiculo> vehiculosABorrar = new ArrayList<>();
        for (int i = 0; i < vehiculos.size(); i++) {
            if (vehiculos.get(i) instanceof Coche) {
                System.out.println("Se ha reparado el Coche con los siguientes datos:");
                System.out.println("Marca: " + vehiculos.get(i).getMarca() + ", modelo: " + vehiculos.get(i).getModelo());
                vehiculosABorrar.add(vehiculos.get(i));
                System.out.println();
            } else if (vehiculos.get(i) instanceof Bicicleta) {
                System.out.println("Se ha reparado una bicicle de " + ((Bicicleta) vehiculos.get(i)).getTipo());
                vehiculosABorrar.add(vehiculos.get(i));
                System.out.println();
            }
        }
        for (Vehiculo v: vehiculosABorrar) vehiculos.remove(v);
    }

    public static void showVehiculos() {
        for (Vehiculo vehiculo: vehiculos) {
            System.out.println(vehiculo.toString());
        }
    }
}
