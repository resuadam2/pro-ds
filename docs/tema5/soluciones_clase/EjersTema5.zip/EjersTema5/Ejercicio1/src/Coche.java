public class Coche extends VehiculoMotorizado {
    private int numPuertas;

    public Coche(String marca, String modelo, int numPuertas, Motor motor) {
        super(marca, modelo, motor);
        this.numPuertas = numPuertas;
    }

    public int getNumPuertas() {
        return numPuertas;
    }

    public void setNumPuertas(int numPuertas) {
        this.numPuertas = numPuertas;
    }

    @Override
    public String toString() {
        return "Coche{" +
                "marca=" + getMarca() +
                ", modelo=" + getModelo() +
                ", numPuertas=" + numPuertas +
                ", motor=" + getMotor() +
                '}';
    }
}
