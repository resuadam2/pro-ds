public class Camion extends VehiculoMotorizado {
    private double cargaMax;

    public Camion(String marca, String modelo, Motor motor, double cargaMax) {
        super(marca, modelo, motor);
        this.cargaMax = cargaMax;
    }

    public double getCargaMax() {
        return cargaMax;
    }

    public void setCargaMax(double cargaMax) {
        this.cargaMax = cargaMax;
    }


    @Override
    public String toString() {
        return "Camion{" +
                "marca=" + getMarca() +
                ", modelo=" + getModelo() +
                ", motor=" + getMotor() +
                ", cargaMax=" + cargaMax +
                '}';
    }
}
