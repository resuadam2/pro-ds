import java.util.LinkedList;

public class Main {
    public static void main(String[] args) {
        LinkedList<Figura> figuras = new LinkedList<>();
        figuras.add(new Circulo(3));
        figuras.add(new Rectangulo(3,2));
        figuras.add(new Triangulo(3, 2));
        for (Figura f: figuras) {
            if (f instanceof Circulo) System.out.println("El área del círculo es: " + f.calcularArea());
            else if (f instanceof Rectangulo) System.out.println("El área del rectángulo es: " + f.calcularArea());
            else System.out.println("El área del triángulo es: " + f.calcularArea());
        }
    }
}
