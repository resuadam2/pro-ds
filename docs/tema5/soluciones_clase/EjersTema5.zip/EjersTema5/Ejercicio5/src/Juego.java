import java.util.*;

public class Juego {
    private final ArrayList<Jugador> jugadores;
    private final Baraja baraja;
    private int numRondas;

    public Juego(ArrayList<Jugador> jugadores, int numCartas) {
        this.jugadores = jugadores;
        this.baraja = new Baraja(numCartas);
        if (baraja.getCartas().size() < jugadores.size() || jugadores.size() < 2) {
            System.out.println("No se puede jugar con el número de cartas o jugadores introducido");
        } else {
            numRondas = baraja.getCartas().size() / jugadores.size();
            jugar();
        }
    }

    public void jugar() {
        repartir();
        while (numRondas > 0) {
           jugarRonda();
        }
        calculoGanadores();
    }

    private void calculoGanadores() {
        int maxGanadas = jugadores.getFirst().getGanadas();
        Jugador winner = jugadores.getFirst();
        for (Jugador jugador: jugadores) {
            if (jugador.getGanadas() > maxGanadas) {
                winner = jugador;
                maxGanadas = jugador.getGanadas();
            }
        }
        boolean empate = false;
        ArrayList<Jugador> ganadores = new ArrayList<>();
        ganadores.add(winner);
        for (Jugador jugador: jugadores) {
            if (jugador == winner) {
                continue;
            }
            if (jugador.getGanadas() == winner.getGanadas()) {
                ganadores.add(jugador);
                empate = true;
            }
        }
        if (empate) {
            System.out.println("Ha habido un empate.");
            System.out.println("Ganadores:");
            for (Jugador jugador : ganadores) {
                System.out.println(jugador.getNombre());
            }
        } else System.out.println("El ganador es " + winner.getNombre());
    }

    private void jugarRonda() {
        System.out.println("Quedan " + numRondas + " rondas.");
        int max = 0;
        for (Jugador jugador : jugadores) {
            if (!jugador.getMazo().isEmpty() && jugador.getMazo().peek().getValor() > max) {
                max = jugador.getMazo().peek().getValor();
            }
            System.out.println("El jugador " + jugador.getNombre() + ":");
            System.out.println(" ha jugado un " + jugador.getMazo().peek().getValor());
        }
        Jugador ganadorRonda = null;
        for (Jugador jugador: jugadores) {
            if (jugador.getMazo().pop().getValor() == max) {
                ganadorRonda = jugador;
                System.out.println("El jugador " + jugador.getNombre() + " gana la ronda.");
            }
        }
        assert ganadorRonda != null; // Comprueba que ganadorRonda no es nulo
        ganadorRonda.setGanadas(ganadorRonda.getGanadas()+1);
        mostrarPuntuaciones();
        numRondas--;
    }

    private void mostrarPuntuaciones()
    {
        for (Jugador jugador : jugadores) {
            System.out.println(jugador.getNombre() + " lleva " + jugador.getGanadas() + " rondas ganadas.");
        }
    }

    private void repartir() {
        baraja.barajar();
        for(int i = 0; i < numRondas; i++) {
            for (Jugador jugador: jugadores) {
                jugador.getMazo().push(baraja.getCartas().pop());
            }
        }
    }
}
