import java.util.ArrayList;
import java.util.Collections;
import java.util.Stack;

public class Baraja {
    private Stack<Carta> cartas;

    public Baraja(int numCartas) {
        cartas = new Stack<>();
        for (int i = 1; i <= numCartas; i++) {
            cartas.push(new Carta(i));
        }
    }

    public void barajar() {
        ArrayList<Carta> cartasBarajadas = new ArrayList<>(cartas);
        Collections.shuffle(cartasBarajadas);
        cartas.clear();
        cartas.addAll(cartasBarajadas);
    }

    public Stack<Carta> getCartas() {
        return cartas;
    }

    public void setCartas(Stack<Carta> cartas) {
        this.cartas = cartas;
    }

    @Override
    public String toString() {
        return "Baraja{" +
                "cartas=" + cartas +
                '}';
    }
}
