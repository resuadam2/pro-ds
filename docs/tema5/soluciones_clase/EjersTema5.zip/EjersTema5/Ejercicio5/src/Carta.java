public class Carta {
    private int valor;

    public Carta(int valor) {
        this.valor = valor;
    }

    public int getValor() {
        return valor;
    }

    public void setValor(int valor) {
        this.valor = valor;
    }

    @Override
    public String toString() {
        return "Carta{" +
                "valor=" + valor +
                '}';
    }
}
