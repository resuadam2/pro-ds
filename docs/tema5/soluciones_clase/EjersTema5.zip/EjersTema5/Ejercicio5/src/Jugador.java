import java.util.Stack;

public class Jugador {
    private String nombre;
    private Stack<Carta> mazo;
    private int ganadas;

    public Jugador(String nombre) {
        this.nombre = nombre;
        this.mazo = new Stack<>();
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public Stack<Carta> getMazo() {
        return mazo;
    }

    public void setMazo(Stack<Carta> mazo) {
        this.mazo = mazo;
    }

    public int getGanadas() {
        return ganadas;
    }

    public void setGanadas(int ganadas) {
        this.ganadas = ganadas;
    }

    @Override
    public String toString() {
        return "Jugador{" +
                "nombre='" + nombre + '\'' +
                ", mazo=" + mazo +
                ", ganadas=" + ganadas +
                '}';
    }
}
