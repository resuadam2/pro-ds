import java.util.HashMap;

public class Main {
    public static void main(String[] args) {
        HashMap<String, Double> areas = new HashMap<>();
        HashMap<String, Double> perimetros = new HashMap<>();

        Figura circulo = new Circulo(3);
        Figura rectangulo = new Rectangulo(3,4);
        Figura triangulo = new Triangulo(3,4);
        areas.put("Círculo", circulo.calcularArea());
        areas.put("Rectángulo", rectangulo.calcularArea());
        areas.put("Triángulo", triangulo.calcularArea());
        perimetros.put("Círculo", circulo.calcularPerimetro());
        perimetros.put("Rectángulo", rectangulo.calcularPerimetro());
        perimetros.put("Triángulo", triangulo.calcularPerimetro());
        for (String clave : areas.keySet()) {
            System.out.println("El área de " + clave + ": " + areas.get(clave));
        }
        for (String clave: perimetros.keySet()) {
            System.out.println("El perímetro de " + clave + ": " + perimetros.get(clave));
        }
    }
}
