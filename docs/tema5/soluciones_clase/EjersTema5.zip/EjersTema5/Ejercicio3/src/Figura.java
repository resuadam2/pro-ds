public interface Figura {
    double calcularArea();
    double calcularPerimetro();
}
