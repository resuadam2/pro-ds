import java.util.ArrayDeque;
import java.util.LinkedList;
import java.util.Queue;


public class Supermercado {
    private Queue<Cliente> cola;

    public Supermercado() {
        cola = new ArrayDeque<>(); // Intercambiable por LinkedList<>();
    }

    public void addCliente(Cliente nuevoCliente) {
        cola.add(nuevoCliente);
    }

    public void atenderClientes() {
        while (!cola.isEmpty()) {
            Cliente c = cola.poll();
            System.out.println("Se ha atendido a " + c.getNombre());
        }
    }
}
