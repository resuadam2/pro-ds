public class Main {
    public static void main(String[] args) {
        Supermercado supermercado = new Supermercado();
        supermercado.addCliente(new Cliente("Pedro"));
        supermercado.addCliente(new Cliente("Susana"));
        supermercado.addCliente(new Cliente("Juan"));
        supermercado.atenderClientes();
    }
}
